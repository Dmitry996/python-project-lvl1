#!/usr/bin/env python3
from brain_games.cli import greeting


def main():
    greeting()


if __name__ == '__main__':
    main()
